import { Box, Link, Flex } from '@chakra-ui/react';

const Navbar = () => {
  return (
    <Flex as="nav" p={4} bg="teal.500" color="white" justifyContent="space-between">
      <Link href="/" fontWeight="bold" fontSize="xl">Bullseye AI</Link>
      <Box>
        <Link href="/" mr={4}>Home</Link>
        <Link href="/about">About</Link>
      </Box>
    </Flex>
  );
};

export default Navbar;