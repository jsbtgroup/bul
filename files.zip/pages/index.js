import { useState } from 'react';
import { Box, Input, Button, Text, Select } from '@chakra-ui/react';
import axios from 'axios';

const Home = () => {
  const [symbol, setSymbol] = useState('');
  const [strategy, setStrategy] = useState('');
  const [prediction, setPrediction] = useState(null);

  const fetchPrediction = async () => {
    const apiKey = process.env.REACT_APP_POLYGON_API_KEY;
    try {
      const response = await axios.get(
        `https://api.polygon.io/v1/open-close/${symbol}/2023-03-20?adjusted=true&apiKey=${apiKey}`
      );
      setPrediction(response.data);
    } catch (error) {
      console.error('Error fetching data', error);
    }
  };

  return (
    <Box p={4}>
      <Text fontSize="2xl" mb={4}>Bullseye AI - Stock Prediction Platform</Text>
      <Input
        placeholder="Enter stock symbol (e.g., AAPL, GOOGL)"
        value={symbol}
        onChange={(e) => setSymbol(e.target.value)}
        mb={4}
      />
      <Select
        placeholder="Select investment strategy"
        value={strategy}
        onChange={(e) => setStrategy(e.target.value)}
        mb={4}
      >
        <option value="long-term">Long-term Growth</option>
        <option value="swing-trading">Swing Trading</option>
        <option value="day-trading">Day Trading</option>
      </Select>
      <Button colorScheme="teal" onClick={fetchPrediction} mb={4}>
        Get Prediction
      </Button>
      {prediction && (
        <Box mt={4}>
          <Text>Close Price: {prediction.close}</Text>
          <Text>Open Price: {prediction.open}</Text>
          <Text>High Price: {prediction.high}</Text>
          <Text>Low Price: {prediction.low}</Text>
          <Text>Volume: {prediction.volume}</Text>
        </Box>
      )}
    </Box>
  );
};

export default Home;