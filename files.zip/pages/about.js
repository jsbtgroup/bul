import { Box, Text, Link } from '@chakra-ui/react';

const About = () => {
  return (
    <Box p={4}>
      <Text fontSize="2xl" mb={4}>About Bullseye AI</Text>
      <Text mb={4}>
        Bullseye AI is a simple MVP for a stock prediction platform that provides investment
        recommendations based on real-time market data and selected trading strategies.
      </Text>
      <Link href="/">Go to Home Page</Link>
    </Box>
  );
};

export default About;